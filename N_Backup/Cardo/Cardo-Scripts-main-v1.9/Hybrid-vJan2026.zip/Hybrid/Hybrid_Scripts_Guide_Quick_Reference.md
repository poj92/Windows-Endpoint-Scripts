# Hybrid Scripts Quick Reference Guide

**Version 1.9 · January 2025**  
**Organization:** Cardo Group Ltd / Nexus Open Systems  
**Support:** Peter James · peter.james@nexusos.co.uk

---

## Overview

18 PowerShell scripts for managing users in hybrid environments (on-premises Active Directory + Microsoft Entra ID via AAD Connect).

**Key Points:**
- Scripts modify AD; changes sync to Entra ID automatically (30-min default)
- Requires: PowerShell 5.1+, Active Directory module, domain controller access
- All bulk operations use CSV files
- Comprehensive logging included

---

## Scripts at a Glance

### User Management (4 scripts)
| Script | Purpose | CSV Input |
|--------|---------|-----------|
| **CreateNewUser.ps1** | Create users with full profiles | First name, Last name, Company*, IsFieldOperative*, Department, Manager Email, etc. |
| **MoveExistingUsersOU.ps1** | Move users between OUs | User principal name, TargetOU |
| **CreateCompanyOUs.ps1** | Create OU structure | Interactive prompt (no CSV) |
| **Set_Operative_Or_NonOperative.ps1** | Change operative status & move OU | User principal name, Company, IsFieldOperative, Department |

### Contact Information (6 scripts)
| Script | Purpose | CSV Input |
|--------|---------|-----------|
| **Update_MobileNumber.ps1** | Update mobile phone | User principal name, Mobile |
| **Update_Telephone.ps1** | Update office phone | User principal name, Telephone number |
| **Update_Address.ps1** | Update address | User principal name, StreetAddress, Post Code, Office |
| **Update_CompanyOrLocation.ps1** | Update company/location | User principal name, Company, Office |
| **Update_Fax_For_Direct-Dial.ps1** | Update fax number | User principal name, Fax |
| **Set_SMTP_Address.ps1** | Set primary email | User principal name |

### Licensing (2 scripts) - Via Extension Attributes
| Script | Purpose | Attribute | CSV Input |
|--------|---------|-----------|-----------|
| **Set_E3NoTeams_License.ps1** | Assign/remove E3 license | extensionAttribute3 | User principal name, E3Only (Yes/No) |
| **Set_D365_Field_License.ps1** | Assign/remove D365 Field | extensionAttribute2 | User principal name, D365FieldService (Yes/No) |

### Phone Authentication (3 scripts) - Uses Microsoft Graph
| Script | Purpose | 
|--------|---------|
| **Add_PhoneAuthenticationMethod.ps1** | Add MFA phone | 
| **Get_PhoneAuthenticationMethod.ps1** | Retrieve MFA phone config | 
| **Remove_PhoneAuthenticationMethod.ps1** | Remove MFA phone | 

### Offboarding & Password (2 scripts)
| Script | Purpose | CSV Input |
|--------|---------|-----------|
| **Leaver_Script.ps1** | Offboard user (disable, convert mailbox, move to _Leavers OU) | User principal name, Account status (must be "Disabled") |
| **Set_Passwords.ps1** | Bulk password reset | User principal name, Password |

---

## CSV Format Quick Reference

### Common Columns by Script

**New User Creation:**
```csv
First name,Last name,Display name,User logon name,User principal name,Password,Account status,Company,IsFieldOperative,Department,Job Title,Mobile,Telephone number,E-mail,Manager Email,StreetAddress,City,Post code,Country,D365FieldService
```

**License Assignment:**
```csv
User principal name,E3Only (or D365FieldService)
john.doe@cardogroup.co.uk,Yes
```

**Contact Updates:**
```csv
User principal name,Mobile (or Telephone number / StreetAddress,Post Code,Office / Company,Office)
```

**Offboarding:**
```csv
User principal name,Account status
john.doe@cardogroup.co.uk,Disabled
```

**Phone Authentication:**
```csv
User principal name,AuthenticationPhone
john.doe@cardogroup.co.uk,+447123456789
```

### Required Fields by Script
| Script | Required Fields |
|--------|-----------------|
| CreateNewUser | First name, Last name, Display name, User logon name, UPN, Password, Account status, **Company**, **IsFieldOperative** |
| MoveExistingUsersOU | User principal name, TargetOU |
| Set_E3NoTeams | User principal name, E3Only |
| Set_D365_Field | User principal name, D365FieldService |
| Set_Operative_Or_NonOperative | User principal name, Company, Display name, **IsFieldOperative** |
| All contact updates | User principal name, [field to update] |
| Phone auth scripts | User principal name, AuthenticationPhone (add only) |
| Leaver_Script | User principal name, Account status (="Disabled") |

---

## Key Concepts

### OU Structure
```
OU=ADUsers
└── OU=[Company]
    ├── OU=Operative          ← IsFieldOperative = "operative"
    └── OU=Non-operative      ← IsFieldOperative = "no"
        ├── OU=Finance
        ├── OU=IT
        ├── OU=Maintenance
        └── OU=Procurement
└── OU=_Leavers              ← Disabled users moved here
```

### Extension Attributes (Sync to Entra ID)
| Attribute | Purpose | Values |
|-----------|---------|--------|
| extensionAttribute1 | Operative status | "operative" or "no" |
| extensionAttribute2 | D365 Field Service license | "Yes" or "No" |
| extensionAttribute3 | E3 (no Teams) license | "Yes" or "No" |

### AAD Connect
- **Sync interval:** Every 30 minutes (automatic)
- **Force sync:** `Start-ADSyncSyncCycle -PolicyType Delta`
- **Full sync:** `Start-ADSyncSyncCycle -PolicyType Initial`

---

## Common Workflows

### 1. Onboard New Field Engineer
1. Prepare CSV with user details, `IsFieldOperative = "operative"`, `D365FieldService = "Yes"`
2. Run `CreateNewUser.ps1` → User placed in Operative OU
3. Wait for AAD Connect sync (30 min)
4. (Optional) Add phone: `Add_PhoneAuthenticationMethod.ps1`
5. Verify in Entra ID portal

### 2. Change Role (Non-Operative → Operative)
```csv
User principal name,Company,Department,Display name,IsFieldOperative
jane.smith@cardogroup.co.uk,Cardo UK,,Jane Smith,operative
```
Run `Set_Operative_Or_NonOperative.ps1` → Updates status and moves OU

### 3. Bulk Address Update (Office Move)
```csv
User principal name,StreetAddress,Post Code,Office
user1@cardogroup.co.uk,New Address,NE1 1AA,Newcastle
```
Run `Update_Address.ps1`

### 4. Offboard Employee
```csv
User principal name,Account status
john.doe@cardogroup.co.uk,Disabled
```
1. Run `Leaver_Script.ps1` → Disables account, converts mailbox to shared, moves to _Leavers
2. Wait for AAD sync
3. Manually remove licenses in Entra ID portal

### 5. Create New Company OU Structure
1. Run `CreateCompanyOUs.ps1`
2. Prompted: "Please enter the Name of the Company"
3. Creates Operative, Non-operative, and department OUs automatically

---

## Prerequisites & Setup

### Install Active Directory Module
```powershell
# Windows Server
Install-WindowsFeature -Name RSAT-AD-PowerShell

# Windows 10/11
Add-WindowsCapability -Online -Name Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0
```

### Required Permissions
- **AD:** Account Operator role or delegated permissions to create/modify users and move between OUs
- **Exchange Online:** Admin role (for Leaver_Script mailbox conversion)
- **Microsoft Graph:** User.Read.All, UserAuthenticationMethod.ReadWrite.All (for phone auth scripts)

### CSV File Location
- Place `UserImport.csv` in same directory as script, OR
- Edit script to specify custom path: `$FilePath = "C:\Path\To\File.csv"`

---

## Troubleshooting (Most Common Issues)

| Issue | Solution |
|-------|----------|
| "Active Directory module not found" | Install RSAT or run on domain controller |
| "Access Denied" | Verify account has Account Operator role or delegated AD permissions |
| "CSV file not found" | Place CSV in script directory or edit script to specify path |
| "Company name missing" / "IsFieldOperative missing" | Add values to all rows in CSV (required fields) |
| "User already exists" | Check if user in AD: `Get-ADUser -Filter "UserPrincipalName -eq 'user@domain.com'"` |
| "OU does not exist" | Run `CreateCompanyOUs.ps1` first to create structure |
| "Manager not found" | Verify manager UPN exists in AD or leave blank |
| "Changes not syncing to Entra ID" | Wait 30 min or force sync: `Start-ADSyncSyncCycle -PolicyType Delta` |
| "Extension attribute not syncing" | Verify attribute included in AAD Connect sync rules |
| "Cannot connect to Exchange" (Leaver Script) | Ensure Exchange admin role and network connectivity |
| "Graph permission error" | Reinstall module: `Install-Module Microsoft.Graph.Identity.Signins -Force` |

---

## Output Files

All scripts create timestamped log files in the script directory:
- `ScriptName_YYYYMMDD_HHMMSS.log`

Review logs for success/error details after each run.

---

## Best Practices

1. **Test first** - Run scripts with 1-2 users before bulk operations
2. **Secure CSV files** - Contain passwords and personal data; delete after use
3. **Batch operations** - Process 100-200 users per batch; allow sync between runs
4. **Schedule off-hours** - Large operations run during low-traffic times
5. **Monitor logs** - Check logs after every script run
6. **Backup before major changes** - Especially for offboarding/OU moves
7. **Document processes** - Keep CSV templates and OU structure documented

---

## Support

**Contact:** Peter James  
**Email:** peter.james@nexusos.co.uk

**Include when reporting issues:**
- Script name
- Full error message from log file
- PowerShell version: `$PSVersionTable.PSVersion`
- Sample CSV


---

*Last Updated: January 5, 2025*  
*Quick Reference Version 1.9*
