# Hybrid Scripts – Quick Guide

## Prerequisites
- PowerShell 5.1+ on Windows with RSAT **Active Directory** module installed
- Access to on-prem AD (domain-joined or DC) and AAD Connect running for sync
- Exchange Online admin role for mailbox steps (Leaver_Script)
- Default CSV is `UserImport.csv` in the script folder; edit script if you want a custom path

Install AD module (examples):
```powershell
# Windows Server
Install-WindowsFeature -Name RSAT-AD-PowerShell
# Windows 10/11
Add-WindowsCapability -Online -Name Rsat.ActiveDirectory.DS-LDS.Tools~~~~0.0.1.0
```

---

## Scripts at a Glance (what + how to run + key CSV columns)

**CreateNewUser.ps1** – Create AD users with full profile
- Run: `./CreateNewUser.ps1`
- CSV required columns: First name, Last name, Display name, User logon name, User principal name, Password, Account status, Company, IsFieldOperative, Department, Job Title, Telephone number, Mobile, E-mail, Manager Email, StreetAddress, City, Post code, Country, Other Name, D365FieldService

**MoveExistingUsersOU.ps1** – Move users between OUs
- Run: `./MoveExistingUsersOU.ps1`
- CSV: User principal name, TargetOU

**CreateCompanyOUs.ps1** – Build company OU structure
- Run: `./CreateCompanyOUs.ps1`
- CSV: Company (one per row)

**Set_E3NoTeams_License.ps1** – Mark for E3 (no Teams)
- Run: `./Set_E3NoTeams_License.ps1`
- CSV: User principal name, E3NoTeams (Yes/No)

**Set_D365_Field_License.ps1** – Mark for D365 Field license
- Run: `./Set_D365_Field_License.ps1`
- CSV: User principal name, D365FieldService (Yes/No)

**Set_Operative_Or_NonOperative.ps1** – Set type + move OU
- Run: `./Set_Operative_Or_NonOperative.ps1`
- CSV: User principal name, IsFieldOperative (Operative | Non-Operative)

**Update_MobileNumber.ps1** – Update mobiles
- Run: `./Update_MobileNumber.ps1`
- CSV: User principal name, Mobile

**Update_Telephone.ps1** – Update office phones
- Run: `./Update_Telephone.ps1`
- CSV: User principal name, Telephone number

**Update_Address.ps1** – Update addresses
- Run: `./Update_Address.ps1`
- CSV: User principal name, StreetAddress, City, Post code, Country

**Update_CompanyOrLocation.ps1** – Update company/location
- Run: `./Update_CompanyOrLocation.ps1`
- CSV: User principal name, Company, OfficeLocation (or similar column used in script)

**Update_Fax_For_Direct-Dial.ps1** – Update fax
- Run: `./Update_Fax_For_Direct-Dial.ps1`
- CSV: User principal name, Fax

**Set_SMTP_Address.ps1** – Set primary SMTP (proxyAddresses)
- Run: `./Set_SMTP_Address.ps1`
- CSV: User principal name, SMTPAddress (new primary)

**Add_PhoneAuthenticationMethod.ps1** – Add MFA phone
- Run: `./Add_PhoneAuthenticationMethod.ps1`
- CSV: User principal name, Mobile (international format)

**Get_PhoneAuthenticationMethod.ps1** – Report MFA phone
- Run: `./Get_PhoneAuthenticationMethod.ps1`
- CSV: User principal name

**Remove_PhoneAuthenticationMethod.ps1** – Remove MFA phone methods
- Run: `./Remove_PhoneAuthenticationMethod.ps1`
- CSV: User principal name

**Remove_MobileNumber.ps1** – Clear mobile attribute
- Run: `./Remove_MobileNumber.ps1`
- CSV: User principal name

**Leaver_Script.ps1** – Offboard hybrid user (disable, move to leavers OU, convert mailbox)
- Run: `./Leaver_Script.ps1`
- CSV: User principal name (mailbox conversion requires Exchange admin rights)

**Set_Passwords.ps1** – Set/reset passwords
- Run: `./Set_Passwords.ps1`
- CSV: User principal name, Password, ChangePasswordAtLogon (True/False)

---

## Quick Tips
- Run from the script folder so default CSV paths work
- Keep CSV headers exact; save as CSV (UTF-8)
- Test with 1–2 rows before bulk updates
- For mailbox actions, sign in with an account that has Exchange Online admin rights
- After changes, allow AAD Connect to sync (or trigger a delta sync) before checking in Entra ID
