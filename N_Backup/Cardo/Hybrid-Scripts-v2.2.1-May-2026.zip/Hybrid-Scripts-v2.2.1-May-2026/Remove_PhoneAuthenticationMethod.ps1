﻿# This script removes the phone authentication method of users

<#
.SYNOPSIS
    This script removes the phone authentication methods for users listed in a CSV file.
.DESCRIPTION
    This script connects to Microsoft Graph and removes the phone authentication methods for each user specified in the
    provided CSV file.
#>

# If the Microsoft Graph module is not installed, install it
if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Identity.SignIns)) {
    Install-Module Microsoft.Graph.Identity.Signins -Force
}

Connect-MgGraph -Scopes "User.Read.all","UserAuthenticationMethod.Read.All","UserAuthenticationMethod.ReadWrite.All"


# Setup the user import csv file location

# Instruct script to search for CSV file from the same location as itself
# If running from PowerShell Window, manually, uncomment line 11 and specify csv filepath accordingly
$executingScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

# Check if UserImport.csv exists in the script directory, if not ask user to provide path
if (-Not (Test-Path -Path (Join-Path $executingScriptDirectory "UserImport.csv"))) {
    Write-Host "UserImport.csv not found in script directory. Please provide the full path to the CSV file" -ForegroundColor Yellow
    $FilePath = Read-Host "File path"
} else {
    $FilePath = Join-Path $executingScriptDirectory "UserImport.csv"
}

$Users = Import-Csv $FilePath


# Remove current phone authenticator methods with reporting
$LogResults = @()
foreach($User in $Users){
    $UserParams = @{
        UserId     = $User.'UserPrincipalName'
        PhoneAuthenticationMethodId = '3179e48a-750b-4051-897c-87b9720928f7' #remember to set correct ID
    }
    $LogEntry = [PSCustomObject]@{
        UserPrincipalName = $User.'UserPrincipalName'
        Status = ''
        Message = ''
    }
    try {
        Remove-MgUserAuthenticationPhoneMethod @UserParams
        Write-Host "Successfully removed phone authentication method for user $($User.'UserPrincipalName')" -ForegroundColor Green
        $LogEntry.Status = 'Success'
        $LogEntry.Message = 'Phone authentication method removed.'
    } catch {
        Write-Host "Failed to remove phone authentication method for user $($User.'UserPrincipalName'): $($_.Exception.Message)" -ForegroundColor Red
        $LogEntry.Status = 'Failed'
        $LogEntry.Message = $_.Exception.Message
    }
    $LogResults += $LogEntry
}

# Export log results to CSV
$ExportPath = Join-Path $executingScriptDirectory "RemovePhoneAuthenticationMethod_Log.csv"
$LogResults | Export-Csv -Path $ExportPath -NoTypeInformation -Encoding UTF8
Write-Host "Log exported to: $ExportPath" -ForegroundColor Yellow

Pause
