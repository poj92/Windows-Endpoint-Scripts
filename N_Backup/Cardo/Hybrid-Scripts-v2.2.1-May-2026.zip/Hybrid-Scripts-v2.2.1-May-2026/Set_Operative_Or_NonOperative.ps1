﻿# Setup the user import csv file location

# Instruct script to search for CSV file from the same location as itself
$executingScriptDirectory = $PSScriptRoot

# Check if UserImport.csv exists in the script directory, if not ask user to provide a valid path
$FilePath = Join-Path $executingScriptDirectory "UserImport.csv"
while (-Not (Test-Path -Path $FilePath)) {
    Write-Host "UserImport.csv not found in script directory. Please provide the full path to the CSV file" -ForegroundColor Yellow
    $FilePath = Read-Host "File path"
    if (-Not (Test-Path -Path $FilePath)) {
        Write-Host "The path provided does not exist. Please try again." -ForegroundColor Yellow
    }
}

# Prepare log file
$timestamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
$logFile = Join-Path $executingScriptDirectory "Set_Operative_Or_NonOperative_$timestamp.log"

function Write-Log {
    param([string]$Message, [ConsoleColor]$Color = 'White')
    $time = (Get-Date).ToString('s')
    $line = "[$time] $Message"
    Write-Host $Message -ForegroundColor $Color
    $line | Out-File -FilePath $logFile -Append -Encoding utf8
}

Write-Log "Starting Set_Operative_Or_NonOperative script" Cyan
Write-Log "Log file: $logFile" Cyan

$Users = Import-Csv $FilePath
Write-Log "Loaded $($Users.Count) user(s) from CSV" Cyan


foreach($User in $Users){
		        
	# Set OU Paths 

	$Company = $User.'Company'
	$Department = $User.'Department'
    if ("" -eq $Company) {
        Write-Log "Company is empty for $($User.'UserPrincipalName'). Skipping this user." Yellow
        continue
    }
	$OUdomain = "OU=Non-operative,OU=$Company,OU=ADUsers,DC=ad,DC=cardogroup,DC=co,DC=uk"
	$DiName = $User.'DisplayName'
		
	$OU = if ($User.'IsFieldOperative' -eq 'Yes'){
               "OU=Operative,OU=$Company,OU=ADUsers,DC=ad,DC=cardogroup,DC=co,DC=uk"
               }
			elseif(($User.'IsFieldOperative' -ne 'Yes') -and ($Department -eq "")){
				Write-Log "Warning: $DiName's department is empty, user will be added to non-operative OU under $Company" Yellow
				"OU=Non-operative,OU=$Company,OU=ADUsers,DC=ad,DC=cardogroup,DC=co,DC=uk"
			}
			elseif(($User.'IsFieldOperative' -ne 'Yes') -and ($Department -ne "")){
				$TestOU = Get-ADOrganizationalUnit -Filter "Name -eq '$Department'" -SearchBase $OUdomain -ErrorAction SilentlyContinue
				if(-not $TestOU){
					Write-Log "Warning: $DiName's department does not match existing OU, user will be added to non-operative OU under $Company" Yellow
					"OU=Non-operative,OU=$Company,OU=ADUsers,DC=ad,DC=cardogroup,DC=co,DC=uk"
						}
					else{
						Write-Log "Warning: $DiName user will be added to $Department OU under $Company" Cyan
						"OU=$Department,OU=Non-operative,OU=$Company,OU=ADUsers,DC=ad,DC=cardogroup,DC=co,DC=uk"
						}
			}
<#				else{
					"OU=$Department,OU=Non-operative,OU=$Company,OU=ADUsers,DC=ad,DC=cardogroup,DC=co,DC=uk"
                } 
#>
	
    $targetOU = Get-ADOrganizationalUnit -Identity $OU -ErrorAction SilentlyContinue
    if (-not $targetOU) {
        Write-Log "Target OU does not exist: $OU. No changes were made for $($User.'UserPrincipalName')." Red
        continue
    }

    $UpnSafe = $User.'UserPrincipalName' -replace "'", "''"
    $ADUser = Get-ADUser -Filter "UserPrincipalName -eq '$UpnSafe'" -Properties SamAccountName, DistinguishedName
    if($null -eq $ADUser){
        Write-Log "'$($User.'UserPrincipalName')' does not exist in active directory, please check that the username is correct" Red
    }
    elseif($User.'IsFieldOperative' -eq ""){
        Write-Log "The field operative field for $($User.'UserPrincipalName') is empty." Yellow
    }
    
    # Settings for operatives
    elseif($User.'IsFieldOperative' -eq 'Yes'){
        Set-ADUser $ADUser.SamAccountName -Replace @{'extensionAttribute1' = $User.'IsFieldOperative'}
        
        Move-ADObject -Identity $ADUser.DistinguishedName -TargetPath $OU
        Write-Log "$($User.'UserPrincipalName') has now been set as an operative. The user has been moved to the correct OU successfully." Green
    }
    
    # settings for non-operatives
    elseif($User.'IsFieldOperative' -eq 'No'){
        Set-ADUser $ADUser.SamAccountName -Replace @{'extensionAttribute1' = $User.'IsFieldOperative'}

        Move-ADObject -Identity $ADUser.DistinguishedName -TargetPath $OU
        Write-Log "$($User.'UserPrincipalName') has now been set as Non-operative. The user has been moved to the correct OU successfully.." Yellow
    }
    else{
        Write-Log "The field operative field for $($User.'UserPrincipalName') is not a valid entry, no changes were made to this user's account" Red
    }
}

Write-Log "Set_Operative_Or_NonOperative script completed" Cyan
Pause
