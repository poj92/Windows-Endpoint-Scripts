<#
.SYNOPSIS
    This script retrieves extension attributes for users in Active Directory based on a CSV file input.
.DESCRIPTION
    This script reads a CSV file containing UserPrincipalNames and retrieves their extension attributes 1-15 from Active Directory.
    The script outputs the results to a CSV file in the same directory as the input file.
    Creates a log file documenting the process and also displays progress in the console.
.PARAMETER CSVPath
    Path to the CSV file containing UserPrincipalNames. If not provided, defaults to "UserImport.csv" in the script directory.
.EXAMPLE
    .\Get_User_ExtensionAttributes.ps1
    .\Get_User_ExtensionAttributes.ps1 -CSVPath "C:\Path\To\UserImport.csv"
.NOTES
    Ensure you have the necessary permissions to read user attributes in Active Directory.
    If you have any questions or need further assistance, please contact Peter James at peter.james@nexusos.co.uk

.VERSION
    2.0
    Date: January 2026
#>

param(
    [string]$CSVPath
)   

try {
    if (-not $CSVPath) {
        $scriptDir = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
        $CSVPath = Join-Path $scriptDir "UserImport.csv"
    }

    # if the CSV file does not exist, prompt user to provide the correct path
    if (-not (Test-Path -Path $CSVPath)) {
        Write-Host "UserImport.csv not found in directory, please enter correct CSV file path:" -ForegroundColor Red
         $CSVPath = Read-Host "Enter full path to CSV file"
        if (-not (Test-Path -Path $CSVPath)) {
            Write-Host "CSV file not found, please try again" -ForegroundColor Red
        return
    }
    }
    # Prepare log file
    $scriptDir = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
    $timestamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
    $logFile = Join-Path $scriptDir "Get_User_ExtensionAttributes_$timestamp.log"
    function Write-Log {
        param([string]$Message, [ConsoleColor]$Color = 'White')
        $time = (Get-Date).ToString('s')
        $line = "[$time] $Message"
        Write-Host $Message -ForegroundColor $Color
        $line | Out-File -FilePath $logFile -Append -Encoding utf8
    }
    # Ensure Active Directory module is available
    if (-not (Get-Module -ListAvailable -Name ActiveDirectory)) {
        Write-Log "ERROR: Active Directory module not found. Please ensure RSAT tools are installed." Red
        Write-Log "  Install RSAT: Add-WindowsCapability -Online -Name Rsat.ActiveDirectory.DS-LDS.Tools" -ForegroundColor Yellow
        return
    }
    Import-Module ActiveDirectory -ErrorAction Stop
    Write-Log "Active Directory module imported successfully" Green
    # Import user data from CSV
    $users = Import-Csv -Path $CSVPath
    $output = @()
    foreach ($user in $users) {
        try {
            $userPrincipalName = $user.'UserPrincipalName'
            if (-not $userPrincipalName) {
                Write-Log "Skipping entry with missing User Principal Name." -Color Yellow
                continue
            }
            # Retrieve user from Active Directory
            $userPrincipalNameSafe = $userPrincipalName -replace "'", "''"
            $adUser = Get-ADUser -Filter "UserPrincipalName -eq '$userPrincipalNameSafe'" -Properties extensionAttribute1,extensionAttribute2,extensionAttribute3,extensionAttribute4,extensionAttribute5,extensionAttribute6,extensionAttribute7,extensionAttribute8,extensionAttribute9,extensionAttribute10,extensionAttribute11,extensionAttribute12,extensionAttribute13,extensionAttribute14,extensionAttribute15
            if (-not $adUser) {
                Write-Log "User '$userPrincipalName' not found in Active Directory." -Color Yellow
                continue
            }
            # Create output object
            $outputObj = [PSCustomObject]@{
                UserPrincipalName   = $userPrincipalName
                ExtensionAttribute1  = $adUser.extensionAttribute1
                ExtensionAttribute2  = $adUser.extensionAttribute2
                ExtensionAttribute3  = $adUser.extensionAttribute3
                ExtensionAttribute4  = $adUser.extensionAttribute4
                ExtensionAttribute5  = $adUser.extensionAttribute5
                ExtensionAttribute6  = $adUser.extensionAttribute6
                ExtensionAttribute7  = $adUser.extensionAttribute7
                ExtensionAttribute8  = $adUser.extensionAttribute8
                ExtensionAttribute9  = $adUser.extensionAttribute9
                ExtensionAttribute10 = $adUser.extensionAttribute10
                ExtensionAttribute11 = $adUser.extensionAttribute11
                ExtensionAttribute12 = $adUser.extensionAttribute12
                ExtensionAttribute13 = $adUser.extensionAttribute13
                ExtensionAttribute14 = $adUser.extensionAttribute14
                ExtensionAttribute15 = $adUser.extensionAttribute15
            }
            $output += $outputObj
            Write-Log "Retrieved extension attributes for user '$userPrincipalName'." -Color Green
        }   
        catch {
            Write-Log ("Error retrieving user {0}: {1}" -f $userPrincipalName, $_.Exception.Message) -Color Red
        }
    }
    # Export results to CSV
    $outputFile = Join-Path $scriptDir "User_ExtensionAttributes_$timestamp.csv"
    $output | Export-Csv -Path $outputFile -NoTypeInformation -Encoding UTF8
    Write-Log "Extension attributes exported to $outputFile" -Color Green
}
catch {
    Write-Log ("Unexpected error: {0}" -f $_.Exception.Message) -Color Red
}   
Pause

