﻿<#
.SYNOPSIS
    This script creates new Active Directory user accounts based on data from a CSV file.
.DESCRIPTION
    This script reads user details from a CSV file and creates new Active Directory user accounts with specified properties.
    It supports setting various attributes including:   
    - Name, GivenName, Surname, DisplayName, OtherName
    - SamAccountName, UserPrincipalName, Title, Department, Company
    - Manager, Organizational Unit (OU) path, Description, Office, OfficePhone, EmailAddress, MobilePhone
    - AccountPassword, AccountStatus (Enabled/Disabled), ChangePasswordAtLogon
    The script also sets extension attributes based on whether the user is a field operative and D365 Field Service status.
.NOTES
    Ensure you have the necessary permissions to create user accounts in Active Directory.
    If you have any questions or need further assistance, please contact Peter James at peter.james@nexusos.co.uk

.VERSION
    2.0
    Date: January 2026

#>

# Setup the script file location
$executingScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

# Check if UserImport.csv exists in the script directory, if not ask user to provide path
if (-Not (Test-Path -Path (Join-Path $executingScriptDirectory "UserImport.csv"))) {
    Write-Host "UserImport.csv not found in script directory. Please provide the full path to the CSV file" -ForegroundColor Yellow
    $FilePath = Read-Host "File path"
} else {
    $FilePath = Join-Path $executingScriptDirectory "UserImport.csv"
}

# Prepare log file
$timestamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
$logFile = Join-Path $executingScriptDirectory "CreateNewUser_$timestamp.log"

function Write-Log {
    param([string]$Message, [ConsoleColor]$Color = 'White')
    $time = (Get-Date).ToString('s')
    $line = "[$time] $Message"
    Write-Host $Message -ForegroundColor $Color
    $line | Out-File -FilePath $logFile -Append -Encoding utf8
}

Write-Log "Starting CreateNewUser script" Cyan
Write-Log "Log file: $logFile" Cyan

$Users = Import-Csv $FilePath
Write-Log "Loaded $($Users.Count) user(s) from CSV" Cyan



# Import the Active Directory module if module is not already installed
# Import-Module ActiveDirectory



# Run through each user
foreach ($User in $Users) {
    try {
        # Retrieve the Manager distinguished name - this allows user to be setup under the right manager
        $managerDN = if ($User.'ManagerEmail') {
            $managerEmailSafe = $User.'ManagerEmail' -replace "'", "''"
            Get-ADUser -Filter "UserPrincipalName -eq '$managerEmailSafe'" -Properties DisplayName |
            Select-Object -ExpandProperty DistinguishedName
        }


       #Check if correct company name is entered and operative srarus in csv file
        if ($User.'Company' -eq "" -or $User.'IsFieldOperative' -eq "") {
            Write-Log "Error: Company name or field operative property has not been set for one or more users. `n This process will now be aborted (no user account has been created). `n Please close PowerShell window and set company name and operative status for all users and re-run the script. `n If you need help, please reach out to Nexus Service Desk." Red
            Pause
		return
                }
		
		# Set OU
		$Company = $User.'Company'
		$Department = $User.'Department'
		$OUdomain = "OU=Non-operative,OU=$Company,OU=ADUsers,DC=ad,DC=cardogroup,DC=co,DC=uk"
		$DiName = $User.'DisplayName'
		
		$OU = if ($User.'IsFieldOperative' -eq 'Yes'){
                "OU=Operative,OU=$Company,OU=ADUsers,DC=ad,DC=cardogroup,DC=co,DC=uk"
                }
				elseif(($User.'IsFieldOperative' -ne 'Yes') -and ($Department -eq "")){
					Write-Log "Warning: $DiName's department is empty, user will be added to non-operative OU under $Company" Yellow
					"OU=Non-operative,OU=$Company,OU=ADUsers,DC=ad,DC=cardogroup,DC=co,DC=uk"
				}
				elseif(($User.'IsFieldOperative' -ne 'Yes') -and ($Department -ne "")){
					$TestOU = Get-ADOrganizationalUnit -Filter "Name -eq '$Department'" -SearchBase $OUdomain -ErrorAction SilentlyContinue
					if(-not $TestOU){
						Write-Log "Warning: $DiName's department does not match existing OU, user will be added to non-operative OU under $Company" Yellow
						"OU=Non-operative,OU=$Company,OU=ADUsers,DC=ad,DC=cardogroup,DC=co,DC=uk"
							}
						else{
							Write-Log "Warning: $DiName user will be added to $Department OU under $Company" Cyan
							"OU=$Department,OU=Non-operative,OU=$Company,OU=ADUsers,DC=ad,DC=cardogroup,DC=co,DC=uk"
							}
				}
<# 				else{
					"OU=$Department,OU=Non-operative,OU=$Company,OU=ADUsers,DC=ad,DC=cardogroup,DC=co,DC=uk"
                } 
#>


        # Define the parameters using a hashtable
        $NewUserParams = @{
            Name                  = "$($User.'FirstName') $($User.'LastName')"
            GivenName             = $User.'FirstName'
            Surname               = $User.'LastName'
            DisplayName           = $User.'DisplayName'
            OtherName             = $User.'OtherName'
            SamAccountName        = $User.'UserLogonName'
            UserPrincipalName     = $User.'UserPrincipalName'
            Title                 = $User.'JobTitle'
            Department            = $User.'Department'
            Company               = $User.'Company'
            Manager               = $managerDN
            Path                  = $OU
            Description           = $User.'Description'
            Office                = $User.'Office'
            OfficePhone           = $User.'TelephoneNumber'
            EmailAddress          = $User.'E-mail'
            MobilePhone           = $User.'Mobile'
            AccountPassword       = (ConvertTo-SecureString $User.'Password' -AsPlainText -Force)
            Enabled               = if ($User.'AccountStatus' -eq "Enabled") { $true } else { $false }
            ChangePasswordAtLogon = $false # 
            City                  = $User.'Office'
            StreetAddress         = $User.'StreetAddress'
            PostalCode            = $User.'PostCode'
        }

        # Check to see if the user already exists in AD
        $userFullName = "$($User.'FirstName') $($User.'LastName')"
        $UpnSafe = $User.'UserPrincipalName' -replace "'", "''"
        $existingUserUPN = Get-ADUser -Filter "UserPrincipalName -eq '$UpnSafe'" -ErrorAction SilentlyContinue
        $existingUserSAM = Get-ADUser -Filter "SamAccountName -eq '$($User.'UserLogonName')'" -ErrorAction SilentlyContinue
        $existingUserName = Get-ADUser -Filter "Name -eq '$userFullName'" -ErrorAction SilentlyContinue
        
        if ($existingUserUPN -or $existingUserSAM -or $existingUserName) {
            # Give a warning if user exists and terminate process
            if ($existingUserUPN) {
                Write-Log "$($User.'UserPrincipalName') already exists in Active Directory." Yellow
            }
            if ($existingUserSAM) {
                Write-Log "User logon name '$($User.'UserLogonName')' already exists in Active Directory." Yellow
            }
            if ($existingUserName) {
                Write-Log "Display name '$userFullName' already exists in Active Directory. This user may have been previously deleted. Contact IT to restore or permanently remove the deleted user." Yellow
            }
        }

            else {
            # User does not exist then proceed to create the new user account
            
                New-ADUser @NewUserParams
                Write-Log "The user $($User.'UserPrincipalName') was created successfully." Green
            
                # Retrieve the newly created user if we need to set extension attributes
                if($User.'IsFieldOperative' -ne "" -or $User.'D365FieldService' -ne ""){
                    $ADUser = Get-ADUser -Filter "UserPrincipalName -eq '$UpnSafe'"
                    
                    if($User.'IsFieldOperative' -ne ""){
                        Set-ADUser $ADUser -Replace @{'extensionAttribute1' = $User.'IsFieldOperative'}
                    }

                    if($User.'D365FieldService' -ne ""){
                        Set-ADUser $ADUser -Replace @{'extensionAttribute2' = $User.'D365FieldService'}
                    }
                }
            }
    }
    catch {
        # Handle any errors that occur during account creation
        Write-Log "Failed to create $($User.'UserPrincipalName') - $($_.Exception.Message)" Red
    }
}

Write-Log "CreateNewUser script completed" Cyan
Pause