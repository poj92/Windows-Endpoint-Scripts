# This script gets department and company details for users from Active Directory

# Setup the user import csv file location

# Instruct script to search for CSV file from the same location as itself
$executingScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

# Check if UserImport.csv exists in the script directory, if not ask user to provide a valid path
$FilePath = Join-Path $executingScriptDirectory "UserImport.csv"
while (-Not (Test-Path -Path $FilePath)) {
    Write-Host "UserImport.csv not found in script directory. Please provide the full path to the CSV file" -ForegroundColor Yellow
    $FilePath = Read-Host "File path"
    if (-Not (Test-Path -Path $FilePath)) {
        Write-Host "The path provided does not exist. Please try again." -ForegroundColor Yellow
    }
}

# Prepare log file
$timestamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
$logFile = Join-Path $executingScriptDirectory "Get_Department_AND_Company_$timestamp.log"

function Write-Log {
    param([string]$Message, [ConsoleColor]$Color = 'White')
    $time = (Get-Date).ToString('s')
    $line = "[$time] $Message"
    Write-Host $Message -ForegroundColor $Color
    $line | Out-File -FilePath $logFile -Append -Encoding utf8
}

Write-Log "Starting Get_Department_AND_Company script" Cyan
Write-Log "Log file: $logFile" Cyan

$Users = Import-Csv $FilePath
Write-Log "Loaded $($Users.Count) user(s) from CSV" Cyan

$Results = @()
foreach($User in $Users){
    $Upn = $User.'UserPrincipalName'
    if ("" -eq $Upn) {
        Write-Log "Error: UserPrincipalName is empty in the CSV." Yellow
        $Results += [PSCustomObject]@{
            UserPrincipalName = $Upn
            DisplayName = ""
            Department = ""
            Company = ""
            Status = "Failed"
            Message = "UserPrincipalName is empty."
        }
        continue
    }

    $UpnSafe = $Upn -replace "'", "''"
    $ADUser = Get-ADUser -Filter "UserPrincipalName -eq '$UpnSafe'" -Properties Department, Company, DisplayName, ExtensionAttribute1, ExtensionAttribute2, ExtensionAttribute3, ExtensionAttribute4, ExtensionAttribute5, ExtensionAttribute6, ExtensionAttribute7, ExtensionAttribute8, ExtensionAttribute9, ExtensionAttribute10, ExtensionAttribute11, ExtensionAttribute12, ExtensionAttribute13, ExtensionAttribute14, ExtensionAttribute15
    if($null -eq $ADUser){
        Write-Log "'$Upn' does not exist in active directory, please check that the username (email) is correct" Red
        $Results += [PSCustomObject]@{
            UserPrincipalName = $Upn
            DisplayName = ""
            Department = ""
            Company = ""
            ExtensionAttribute1 = ""
            ExtensionAttribute2 = ""
            ExtensionAttribute3 = ""
            ExtensionAttribute4 = ""
            ExtensionAttribute5 = ""
            ExtensionAttribute6 = ""
            ExtensionAttribute7 = ""
            ExtensionAttribute8 = ""
            ExtensionAttribute9 = ""
            ExtensionAttribute10 = ""
            ExtensionAttribute11 = ""
            ExtensionAttribute12 = ""
            ExtensionAttribute13 = ""
            ExtensionAttribute14 = ""
            ExtensionAttribute15 = ""
            Status = "Failed"
            Message = "User not found in Active Directory."
        }
        continue
    }

    $Results += [PSCustomObject]@{
        UserPrincipalName = $Upn
        DisplayName = $ADUser.DisplayName
        Department = $ADUser.Department
        Company = $ADUser.Company
        ExtensionAttribute1 = $ADUser.ExtensionAttribute1
        ExtensionAttribute2 = $ADUser.ExtensionAttribute2
        ExtensionAttribute3 = $ADUser.ExtensionAttribute3
        ExtensionAttribute4 = $ADUser.ExtensionAttribute4
        ExtensionAttribute5 = $ADUser.ExtensionAttribute5
        ExtensionAttribute6 = $ADUser.ExtensionAttribute6
        ExtensionAttribute7 = $ADUser.ExtensionAttribute7
        ExtensionAttribute8 = $ADUser.ExtensionAttribute8
        ExtensionAttribute9 = $ADUser.ExtensionAttribute9
        ExtensionAttribute10 = $ADUser.ExtensionAttribute10
        ExtensionAttribute11 = $ADUser.ExtensionAttribute11
        ExtensionAttribute12 = $ADUser.ExtensionAttribute12
        ExtensionAttribute13 = $ADUser.ExtensionAttribute13
        ExtensionAttribute14 = $ADUser.ExtensionAttribute14
        ExtensionAttribute15 = $ADUser.ExtensionAttribute15
        Status = "Success"
        Message = ""
    }

    Write-Log "Success: Retrieved Department and Company for $Upn" Green
}

$ExportPath = Join-Path $executingScriptDirectory "Get_Department_AND_Company_$timestamp.csv"
$Results | Export-Csv -Path $ExportPath -NoTypeInformation -Encoding UTF8
Write-Log "Results exported to: $ExportPath" Cyan

Write-Log "Get_Department_AND_Company script completed" Cyan
Pause
