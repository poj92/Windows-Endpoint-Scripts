﻿# This script sets E3 (no Teams) license for Cardo users

# Instruct script to search for CSV file from the same location as itself
$executingScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

# Check if UserImport.csv exists in the script directory, if not ask user to provide path
if (-Not (Test-Path -Path (Join-Path $executingScriptDirectory "UserImport.csv"))) {
    Write-Host "UserImport.csv not found in script directory. Please provide the full path to the CSV file" -ForegroundColor Yellow
    $FilePath = Read-Host "File path"
} else {
    $FilePath = Join-Path $executingScriptDirectory "UserImport.csv"
}

# Prepare log file
$timestamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
$logFile = Join-Path $executingScriptDirectory "Set_E3NoTeams_License_$timestamp.log"

function Write-Log {
    param([string]$Message, [ConsoleColor]$Color = 'White')
    $time = (Get-Date).ToString('s')
    $line = "[$time] $Message"
    Write-Host $Message -ForegroundColor $Color
    $line | Out-File -FilePath $logFile -Append -Encoding utf8
}

Write-Log "Starting Set_E3NoTeams_License script" Cyan
Write-Log "Log file: $logFile" Cyan

$Users = Import-Csv $FilePath
Write-Log "Loaded $($Users.Count) user(s) from CSV" Cyan


foreach($User in $Users){
    $UpnSafe = $User.'UserPrincipalName' -replace "'", "''"
    $ADUser = Get-ADUser -Filter "UserPrincipalName -eq '$UpnSafe'" -Properties SamAccountName
    if($null -eq $ADUser){
        Write-Log "'$($User.'UserPrincipalName')' does not exist in active directory, please check that the username is correct" Red
    }
    elseif($User.'E3Only' -eq ""){
        Write-Log "Error: The E3Only field for $($User.'UserPrincipalName') is empty, please check the csv file." Yellow
    }
    
    # Adding license
    elseif($User.'E3Only' -eq 'Yes'){
        Set-ADUser $ADUser.SamAccountName -Replace @{'extensionAttribute3' = $User.'E3Only'}
        Write-Log "Success: An E3 (no Teams) license will be assigned to $($User.'UserPrincipalName')" Green
    }
    
    # Removing license
    elseif($User.'E3Only' -eq 'No'){
        Set-ADUser $ADUser.SamAccountName -Replace @{'extensionAttribute3' = $User.'E3Only'}
        Write-Log "Success: An E3 (no Teams) license will be removed from $($User.'UserPrincipalName')" Yellow
    }
    else{
        Write-Log "The E3Only field for $($User.'UserPrincipalName') is not a valid entry, no changes were made to this user's account" Red
    }
}

Write-Log "Set_E3NoTeams_License script completed" Cyan
Pause
