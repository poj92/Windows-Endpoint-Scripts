﻿# This script updates user's StreetAddress, City and PostalCode

# Setup the user import csv file location

# Instruct script to search for CSV file from the same location as itself
# If running from PowerShell Window, manually, uncomment line 11 and specify csv filepath accordingly
$executingScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

# Check if UserImport.csv exists in the script directory, if not ask user to provide path
if (-Not (Test-Path -Path (Join-Path $executingScriptDirectory "UserImport.csv"))) {
    Write-Host "UserImport.csv not found in script directory. Please provide the full path to the CSV file" -ForegroundColor Yellow
    $FilePath = Read-Host "File path"
} else {
    $FilePath = Join-Path $executingScriptDirectory "UserImport.csv"
}

# Prepare log file
$timestamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
$logFile = Join-Path $executingScriptDirectory "Update_Address_$timestamp.log"

function Write-Log {
    param([string]$Message, [ConsoleColor]$Color = 'White')
    $time = (Get-Date).ToString('s')
    $line = "[$time] $Message"
    Write-Host $Message -ForegroundColor $Color
    $line | Out-File -FilePath $logFile -Append -Encoding utf8
}

Write-Log "Starting Update_Address script" Cyan
Write-Log "Log file: $logFile" Cyan

$Users = Import-Csv $FilePath
Write-Log "Loaded $($Users.Count) user(s) from CSV" Cyan


foreach($User in $Users){
    $UpnSafe = $User.'UserPrincipalName' -replace "'", "''"
    $ADUser = Get-ADUser -Filter "UserPrincipalName -eq '$UpnSafe'" -Properties SamAccountName
    if($null -eq $ADUser){
        Write-Log "'$($User.'UserPrincipalName')' does not exist in active directory, please check that the username is correct" Red
    }
    elseif("" -eq $User.'StreetAddress' -or "" -eq $User.'PostCode'){
        Write-Log "Error: The address or post code field for $($User.'UserPrincipalName') is empty, please check the csv file." Yellow
        break
    }
    
    # Set Address
    else{
        Set-ADUser $ADUser.SamAccountName -StreetAddress $User.'StreetAddress' -PostalCode $User.'PostCode' -City $User.'Office'
        Write-Log "Success: The address and post code for $($User.'UserPrincipalName') has been updated" Green
    }
}

Write-Log "Update_Address script completed" Cyan
Pause
