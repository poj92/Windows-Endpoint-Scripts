﻿# This script sets Dynamics Field service license for Cardo users

# Instruct script to search for CSV file from the same location as itself
$executingScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
# Check if UserImport.csv exists in the script directory, if not ask user to provide path
if (-Not (Test-Path -Path (Join-Path $executingScriptDirectory "UserImport.csv"))) {
    Write-Host "UserImport.csv not found in script directory. Please provide the full path to the CSV file" -ForegroundColor Yellow
    $FilePath = Read-Host "File path"
} else {
    $FilePath = Join-Path $executingScriptDirectory "UserImport.csv"
}

# Prepare log file
$timestamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
$logFile = Join-Path $executingScriptDirectory "Set_D365_Field_License_$timestamp.log"

function Write-Log {
    param([string]$Message, [ConsoleColor]$Color = 'White')
    $time = (Get-Date).ToString('s')
    $line = "[$time] $Message"
    Write-Host $Message -ForegroundColor $Color
    $line | Out-File -FilePath $logFile -Append -Encoding utf8
}

Write-Log "Starting Set_D365_Field_License script" Cyan
Write-Log "Log file: $logFile" Cyan

$Users = Import-Csv $FilePath
Write-Log "Loaded $($Users.Count) user(s) from CSV" Cyan


foreach($User in $Users){
    $UpnSafe = $User.'UserPrincipalName' -replace "'", "''"
    $ADUser = Get-ADUser -Filter "UserPrincipalName -eq '$UpnSafe'" -Properties SamAccountName
    if($null -eq $ADUser){
        Write-Log "'$($User.'UserPrincipalName')' does not exist in active directory, please check that the username is correct" Red
    }
    elseif($User.'D365FieldService' -eq ""){
        Write-Log "Error: The Dynamics 365 Field Service field for $($User.'UserPrincipalName') is empty, please check the csv file." Yellow
    }
    
    # Adding license
    elseif($User.'D365FieldService' -eq 'Yes'){
        Set-ADUser $ADUser.SamAccountName -Replace @{'extensionAttribute2' = $User.'D365FieldService'}
        Write-Log "Success: A Dynamics 365 Field Service license will now be assigned to $($User.'UserPrincipalName')" Green
    }
    
    # Removing license
    elseif($User.'D365FieldService' -eq 'No'){
        Set-ADUser $ADUser.SamAccountName -Replace @{'extensionAttribute2' = $User.'D365FieldService'}
        Write-Log "Success: A Dynamics 365 Field Service license will now be removed from $($User.'UserPrincipalName')" Yellow
    }
    else{
        Write-Log "The Dynamics 365 Field Service field for $($User.'UserPrincipalName') is not a valid entry, no changes were made to this user's account" Red
    }
}

Write-Log "Set_D365_Field_License script completed" Cyan
Pause
