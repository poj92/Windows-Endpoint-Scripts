﻿<#
.SYNOPSIS
    This script adds phone authentication method for users in Azure AD.
.DESCRIPTION
    This script connects to Microsoft Graph and adds a phone authentication method for each user specified in the provided CSV file.
    The CSV file should contain columns named 'UserPrincipalName' and 'AuthenticationPhone'
    with the UPNs of the users and the phone numbers to be added respectively.
.NOTES
    Ensure you have the necessary permissions to read and write user authentication methods in Microsoft Graph.
    Ensure Phone number is in correct format, e.g., +44123456789
#>

# This script updates authentication mobile number

# Check if the Microsoft Graph module is installed, if not install it
if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Identity.SignIns)) {
    Install-Module Microsoft.Graph.Identity.Signins -Force
}

Connect-MgGraph -Scopes "User.Read.all","UserAuthenticationMethod.Read.All","UserAuthenticationMethod.ReadWrite.All"


# Instruct script to search for CSV file from the same location as itself
$executingScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

# If the CSV file does not exist in the script directory, prompt user to provide the path
if (-Not (Test-Path -Path (Join-Path $executingScriptDirectory "UserImport.csv"))) {
    Write-Host "UserImport.csv not found in script directory. Please provide the full path to the CSV file" -ForegroundColor Yellow
    $FilePath = Read-Host "File path"
} else {
    $FilePath = Join-Path $executingScriptDirectory "UserImport.csv"
}   

$Users = Import-Csv $FilePath


# Set Phone number for authentication with format validation
$LogResults = @()
foreach($User in $Users){
    $Phone = $User.'AuthenticationPhone'
    $LogEntry = [PSCustomObject]@{
        UserPrincipalName = $User.'UserPrincipalName'
        AuthenticationPhone = $Phone
        Status = ''
        Message = ''
    }
    # Validate phone number format: E.164 (e.g., +44123456789, +15551234567)
    if ($Phone -match '^\+[1-9]\d{7,14}$') {
        $UserParams = @{
            UserId      = $User.'UserPrincipalName'
            phoneType   = "mobile"
            phoneNumber = $Phone
        }
        try {
            New-MgUserAuthenticationPhoneMethod @UserParams
            Write-Host "Successfully added AuthenticationPhone for user $($User.'UserPrincipalName'): $Phone" -ForegroundColor Green
            $LogEntry.Status = 'Success'
            $LogEntry.Message = 'Phone authentication method added.'
        } catch {
            Write-Host "Failed to add AuthenticationPhone for user $($User.'UserPrincipalName'): $($_.Exception.Message)" -ForegroundColor Red
            $LogEntry.Status = 'Failed'
            $LogEntry.Message = $_.Exception.Message
        }
    } else {
        Write-Host "Invalid phone number format for user $($User.'UserPrincipalName'): $Phone. Expected E.164 format, e.g., +44123456789 or +15551234567" -ForegroundColor Red
        $LogEntry.Status = 'Invalid Format'
        $LogEntry.Message = 'Invalid phone number format.'
    }
    $LogResults += $LogEntry
}

# Export log results to CSV
$ExportPath = Join-Path $executingScriptDirectory "AddPhoneAuthenticationMethod_Log.csv"
$LogResults | Export-Csv -Path $ExportPath -NoTypeInformation -Encoding UTF8
Write-Host "Log exported to: $ExportPath" -ForegroundColor Yellow

Pause
