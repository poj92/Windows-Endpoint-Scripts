﻿# This script sets the SMTP address for users

# Instruct script to search for CSV file from the same location as itself
$executingScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

# Check if UserImport.csv exists in the script directory, if not ask user to provide path
if (-Not (Test-Path -Path (Join-Path $executingScriptDirectory "UserImport.csv"))) {
    Write-Host "UserImport.csv not found in script directory. Please provide the full path to the CSV file" -ForegroundColor Yellow
    $FilePath = Read-Host "File path"
} else {
    $FilePath = Join-Path $executingScriptDirectory "UserImport.csv"
}

# Prepare log file
$timestamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
$logFile = Join-Path $executingScriptDirectory "Set_SMTP_Address_$timestamp.log"

function Write-Log {
    param([string]$Message, [ConsoleColor]$Color = 'White')
    $time = (Get-Date).ToString('s')
    $line = "[$time] $Message"
    Write-Host $Message -ForegroundColor $Color
    $line | Out-File -FilePath $logFile -Append -Encoding utf8
}

Write-Log "Starting Set_SMTP_Address script" Cyan
Write-Log "Log file: $logFile" Cyan

$Users = Import-Csv $FilePath
Write-Log "Loaded $($Users.Count) user(s) from CSV" Cyan

$Results = @()

foreach($User in $Users){
    $UpnSafe = $User.'UserPrincipalName' -replace "'", "''"
    $ADUser = Get-ADUser -Filter "UserPrincipalName -eq '$UpnSafe'" -Properties Enabled, SamAccountName

    if($null -eq $ADUser){
	$msg = "'$($User.'UserPrincipalName')' does not exist in active directory, please check that the username is correct"
        Write-Log $msg Red
	
	$Results += [PSCustomObject]@{
            UserPrincipalName = $User.'UserPrincipalName'
            Output           	= $msg
        	}
                      }
    
    # Setting primary email
    elseif($ADUser.Enabled -eq $False){
	
	$msg = "$($User.'UserPrincipalName') is disabled"
        Write-Log $msg DarkRed
	
	$Results += [PSCustomObject]@{
            UserPrincipalName = $User.'UserPrincipalName'
            Output           	= $msg
        	}
        }   

    else{
        $SMTPAddress = "SMTP:$($User.'UserPrincipalName')"
        Set-ADUser $ADUser.SamAccountName -Replace @{'proxyAddresses' = "$SMTPAddress"}
	
	$msg = "Success: Primary email address for $($User.'UserPrincipalName') has been set to $SMTPAddress"
        Write-Log $msg Yellow
	
	$Results += [PSCustomObject]@{
            UserPrincipalName = $User.'UserPrincipalName'
            Output           	= $msg
        	}

        }
}

$Results | Export-Csv -Path "$executingScriptDirectory\results.csv" -NoTypeInformation

Write-Log "`nResults have written to $executingScriptDirectory\results.csv" Cyan
Write-Log "Set_SMTP_Address script completed" Cyan
Pause
