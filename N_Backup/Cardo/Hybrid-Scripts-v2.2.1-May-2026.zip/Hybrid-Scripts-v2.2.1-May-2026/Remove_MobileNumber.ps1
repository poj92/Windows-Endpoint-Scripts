﻿# This script removes user's mobile phone number

# Instruct script to search for CSV file from the same location as itself
$executingScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

# Check if UserImport.csv exists in the script directory, if not ask user to provide path
if (-Not (Test-Path -Path (Join-Path $executingScriptDirectory "UserImport.csv"))) {
    Write-Host "UserImport.csv not found in script directory. Please provide the full path to the CSV file" -ForegroundColor Yellow
    $FilePath = Read-Host "File path"
} else {
    $FilePath = Join-Path $executingScriptDirectory "UserImport.csv"
}

# Prepare log file
$timestamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
$logFile = Join-Path $executingScriptDirectory "Remove_MobileNumber_$timestamp.log"

function Write-Log {
    param([string]$Message, [ConsoleColor]$Color = 'White')
    $time = (Get-Date).ToString('s')
    $line = "[$time] $Message"
    Write-Host $Message -ForegroundColor $Color
    $line | Out-File -FilePath $logFile -Append -Encoding utf8
}

Write-Log "Starting Remove_MobileNumber script" Cyan
Write-Log "Log file: $logFile" Cyan

$Users = Import-Csv $FilePath
Write-Log "Loaded $($Users.Count) user(s) from CSV" Cyan


foreach($User in $Users){
    $UpnSafe = $User.'UserPrincipalName' -replace "'", "''"
    $ADUser = Get-ADUser -Filter "UserPrincipalName -eq '$UpnSafe'" -Properties SamAccountName
    if($null -eq $ADUser){
        Write-Log "'$($User.'UserPrincipalName')' does not exist in active directory, please check that the username (email) is correct" Red
    }
    
    # Remove Mobile Number
    else{
        Set-ADUser $ADUser.SamAccountName -Clear mobile
        Write-Log "Success: Mobile number has been removed for $($User.'UserPrincipalName')" Green
    }
}

Write-Log "Remove_MobileNumber script completed" Cyan
Pause
