# This script sets extension attributes for users in Active Directory

# Setup the user import csv file location

# Instruct script to search for CSV file from the same location as itself
$executingScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

# Check if UserImport.csv exists in the script directory, if not ask user to provide a valid path
$FilePath = Join-Path $executingScriptDirectory "UserImport.csv"
while (-Not (Test-Path -Path $FilePath)) {
	Write-Host "UserImport.csv not found in script directory. Please provide the full path to the CSV file" -ForegroundColor Yellow
	$FilePath = Read-Host "File path"
	if (-Not (Test-Path -Path $FilePath)) {
		Write-Host "The path provided does not exist. Please try again." -ForegroundColor Yellow
	}
}

# Prepare log file
$timestamp = (Get-Date).ToString('yyyyMMdd_HHmmss')
$logFile = Join-Path $executingScriptDirectory "Set_Extension_Attributes_$timestamp.log"

function Write-Log {
	param([string]$Message, [ConsoleColor]$Color = 'White')
	$time = (Get-Date).ToString('s')
	$line = "[$time] $Message"
	Write-Host $Message -ForegroundColor $Color
	$line | Out-File -FilePath $logFile -Append -Encoding utf8
}

Write-Log "Starting Set_Extension_Attributes script" Cyan
Write-Log "Log file: $logFile" Cyan

$Users = Import-Csv $FilePath
Write-Log "Loaded $($Users.Count) user(s) from CSV" Cyan

foreach($User in $Users){
	$Upn = $User.'UserPrincipalName'
	if ("" -eq $Upn) {
		Write-Log "Error: UserPrincipalName is empty in the CSV." Yellow
		continue
	}

	$UpnSafe = $Upn -replace "'", "''"
	$ADUser = Get-ADUser -Filter "UserPrincipalName -eq '$UpnSafe'" -Properties SamAccountName
	if($null -eq $ADUser){
		Write-Log "'$Upn' does not exist in active directory, please check that the username (email) is correct" Red
		continue
	}

	$Replace = @{}
	foreach ($i in 1..15) {
		$columnName = "ExtensionAttribute$i"
		$value = $User.$columnName
		if ("" -ne $value -and $null -ne $value) {
			$Replace["extensionAttribute$i"] = $value
		}
	}

	if ($Replace.Count -eq 0) {
		Write-Log "No extension attributes provided for $Upn. No changes were made." Yellow
		continue
	}

	try {
		Set-ADUser $ADUser.SamAccountName -Replace $Replace
		$UpdatedAttributes = ($Replace.Keys | Sort-Object) -join ", "
		Write-Log "Success: Updated $UpdatedAttributes for $Upn" Green
	}
	catch {
		Write-Log "Failed to update extension attributes for $Upn: $($_.Exception.Message)" Red
	}
}

Write-Log "Set_Extension_Attributes script completed" Cyan
Pause
