﻿
<#
.SYNOPSIS
    This script retrieves the phone authentication methods for users listed in a CSV file.

.DESCRIPTION
    This script connects to Microsoft Graph and retrieves the phone authentication methods for each user specified in the provided CSV file.
    The CSV file should contain a column named 'UserPrincipalName' with the UPNs of the users.
.NOTES
    Ensure you have the necessary permissions to read user authentication methods in Microsoft Graph.
#>


# Check if the Microsoft Graph module is installed, if not install it
if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Identity.SignIns)) {
    Install-Module Microsoft.Graph.Identity.Signins -Force
}

Connect-MgGraph -Scopes "User.Read.all","UserAuthenticationMethod.Read.All","UserAuthenticationMethod.ReadWrite.All"

# Instruct script to search for CSV file from the same location as itself
$executingScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

# If the CSV file does not exist in the script directory, prompt user to provide the path
if (-Not (Test-Path -Path (Join-Path $executingScriptDirectory "UserImport.csv"))) {
    Write-Host "UserImport.csv not found in script directory. Please provide the full path to the CSV file" -ForegroundColor Yellow
    $FilePath = Read-Host "File path"
} else {
    $FilePath = Join-Path $executingScriptDirectory "UserImport.csv"
}   

$Users = Import-Csv $FilePath


# List current authenticator methods and collect results
$Results = @()
foreach($User in $Users){
    $UserParams = @{
        UserId = $User.'UserPrincipalName'
    }
    $Methods = Get-MgUserAuthenticationPhoneMethod @UserParams
    if ($Methods) {
        foreach ($Method in $Methods) {
            $Result = [PSCustomObject]@{
                UserPrincipalName = $User.'UserPrincipalName'
                PhoneType        = $Method.PhoneType
                PhoneNumber      = $Method.PhoneNumber
                Id               = $Method.Id
            }
            $Results += $Result
            # Display in console
            Write-Host "User: $($Result.UserPrincipalName) | Type: $($Result.PhoneType) | Number: $($Result.PhoneNumber) | Id: $($Result.Id)"
        }
    } else {
        Write-Host "User: $($User.'UserPrincipalName') has no phone authentication methods."
    }
}

# Export results to CSV
$ExportPath = Join-Path $executingScriptDirectory "PhoneAuthenticationMethods_Report.csv"
if ($Results.Count -gt 0) {
    $Results | Export-Csv -Path $ExportPath -NoTypeInformation -Encoding UTF8
    Write-Host "Results exported to: $ExportPath"
} else {
    Write-Host "No phone authentication methods found for any user."
}

Pause
